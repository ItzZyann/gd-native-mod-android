#ifndef _CCCreateMenuItem_h
#define _CCCreateMenuItem_h

#include "cocos2d.h"
#include "CCMenuItemSpriteExtra.h"
#include "AddressTables.hpp"

NS_CC_BEGIN

class CC_DLL CCCreateMenuItem : public CCMenuItemSpriteExtra
{
public:
	//bool init();
	//static CCCreateMenuItem* create();
};

NS_CC_END

#endif